/*
 Navicat MySQL Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 50540
 Source Host           : localhost:3306
 Source Schema         : blog

 Target Server Type    : MySQL
 Target Server Version : 50540
 File Encoding         : 65001

 Date: 31/08/2022 20:08:12
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for hibernate_sequence
-- ----------------------------
DROP TABLE IF EXISTS `hibernate_sequence`;
CREATE TABLE `hibernate_sequence`  (
  `next_val` bigint(20) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of hibernate_sequence
-- ----------------------------
INSERT INTO `hibernate_sequence` VALUES (61);
INSERT INTO `hibernate_sequence` VALUES (61);
INSERT INTO `hibernate_sequence` VALUES (61);
INSERT INTO `hibernate_sequence` VALUES (61);
INSERT INTO `hibernate_sequence` VALUES (61);

-- ----------------------------
-- Table structure for t_blog
-- ----------------------------
DROP TABLE IF EXISTS `t_blog`;
CREATE TABLE `t_blog`  (
  `id` bigint(20) NOT NULL,
  `appreciation` bit(1) NOT NULL,
  `commentabled` bit(1) NOT NULL,
  `content` mediumtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `create_time` datetime NULL DEFAULT NULL,
  `first_picture` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `flag` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `publicshed` bit(1) NOT NULL,
  `recommend` bit(1) NOT NULL,
  `share_statement` bit(1) NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `update_time` datetime NULL DEFAULT NULL,
  `views` int(11) NULL DEFAULT NULL,
  `type_id` bigint(20) NULL DEFAULT NULL,
  `user_user` bigint(20) NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FK292449gwg5yf7ocdlmswv9w4j`(`type_id`) USING BTREE,
  INDEX `FK6hpm0u9snnamsolg1de2eno87`(`user_user`) USING BTREE,
  CONSTRAINT `FK292449gwg5yf7ocdlmswv9w4j` FOREIGN KEY (`type_id`) REFERENCES `t_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK6hpm0u9snnamsolg1de2eno87` FOREIGN KEY (`user_user`) REFERENCES `t_user` (`user`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of t_blog
-- ----------------------------
INSERT INTO `t_blog` VALUES (28, b'1', b'1', '## 1 \r\n不论在什么行业或领域，提高技能与能力的最有效方法全都遵循一系列普遍原则，就是刻意练习。成为任何领域高手的关键因素不是文化，不是艺术，不是哲学，不是制度，不是自虐，而是刻意练习。\r\n\r\n## 2\r\n关于刻意练习，被误读最久的一个概念是“一万小时定律”。事实上，想把自己变成高手，光知道“一万小时”毫无意义，因为真正的关键根本不在训练时间，而是训练的方法。\r\n\r\n## 3\r\n功夫就在功夫上，“功夫在诗外”就是一句谎言。技能是人脑中的一种硬件结构，是“长”在人脑中的。要高度针对性地重复练习基本功，想要学什么功夫，就应该练什么功夫。\r\n\r\n## 4\r\n心理学家把人的知识和技能分为层层嵌套的三个圆形区域：最内一层是“舒适区”，是我们已经熟练掌握的各种技能；最外一层是“恐慌区”，是我们暂时无法学会的技能；二者中间则是“学习区”。\r\n\r\n## 5\r\n在“舒适区”做事，叫生活；在“学习区”做事，才叫练习。有效的练习必须发生在“学习区”，一旦你学会了某个东西，就不该在上面继续花时间，要立即转入下一个难度。凡是达到“我闭着眼睛都能……”这个程度的人都废了，高手不会闭着眼睛做事。\r\n\r\n## 6\r\n只有结果可控的领域，刻意练习才有用。股市是不可控的，所以刻意练习预测股市很可能就没用。有严格固定规则的领域，练习的作用最大，比如国际象棋；没有严格规则的领域，练习的作用则非常有限，如编程、航空飞行、广告创意。\r\n\r\n## 7\r\n把要训练的内容分成有针对性的小块，对每一个小块进行重复练习。艺术家要采风，棋手要打谱，律师要学案例，政客要读历史，科学家要看论文。宁可定期坚持发几篇灌水小文章，也比苦读10年期待一鸣惊人强。\r\n\r\n## 8.\r\n刻意练习的关键是随时获得有效的反馈。你需要一个旁观者，他不见得水平比你高，不需要经常跟你谈心，不用激发你的战斗热情，但他必须给你提供三步反馈：演示一遍正确动作，表现一遍错误动作，再演示一遍正确动作。\r\n\r\n## 9\r\n有效的反馈，应该满足三个条件： 及时，一旦不对马上就有人给你指出来；超脱，对事不对人，反馈者不把你的错误上升到“你这个人行不行”的层面；试错，你犯错误的代价很小。\r\n\r\n## 10\r\n考试是最好的反馈。熟悉并不等于理解，想要真正理解，唯一的办法是考试和测验。没有经过测验，你的知识只是幻觉。\r\n\r\n## 11\r\n学习时间长不等于用功，决定性因素不是学习时间，而是学习环境。刻意练习不好玩，如果你在打打闹闹中享受练习的过程，那就不是刻意练习。你必须在一个不受打扰的环境中单独学习，调动大量的身体和精神资源，全力投入。特别专注地干一件事才是最酷的。\r\n\r\n## 12\r\n刻意练习最为关键的一点，是敢于迈出从舒适区往外走的那一步。你不但应该在“学习区”刻意练习，你的研究、工作和娱乐都应该在“学习区”。刻意练习可以使几乎任何人在大多数领域成为高手，如果能更早知道这一点，你在奋斗路上也许可以节省更多时间和精力。\r\n\r\n', '2022-04-09 21:47:11', 'https://picsum.photos/id/1005/800/450', '转载', b'1', b'1', b'1', '关于刻意练习', '2022-04-05 16:27:49', 25, 36, 1, '不论在什么行业或领域，提高技能与能力的最有效方法全都遵循一系列普遍原则，就是刻意练习。成为任何领域高手的关键因素不是文化，不是艺术，不是哲学，不是制度，不是自虐，而是刻意练习。');
INSERT INTO `t_blog` VALUES (29, b'1', b'1', '不论是vue项目还是react项目，在添加新功能页面时，都需要进行手动配置路由表才会生效。\r\n\r\n那么有没有可能在按照一定格式创建文件之后，会自动添加到路由配置表 里呢？\r\n\r\n答案当然是可以！\r\n\r\n思路：\r\n\r\n检索指定文件夹下的文件 （ require.context(directory, useSubdirectories, regExp) ）\r\ndirectory{String} -读取文件的路径\r\nuseSubdirectories{Boolean} -是否遍历文件的子目录\r\nregExp{RegExp} -匹配文件的正则\r\n将需要生成路由的文件创建在指定位置\r\n以vue项目为例，代码很low，不要吐槽\r\n\r\n1. 改造router/index.js\r\n```html\r\nimport Vue from \"vue\";\r\nimport VueRouter from \"vue-router\";\r\n\r\nVue.use(VueRouter);\r\n\r\nconst routes = []; // 路由配置表\r\n\r\nrequire\r\n  .context(\"../views\", true, /\\.vue$/) \r\n  .keys()\r\n  .map((item) => {\r\n    let path = item.slice(1).replace(\".vue\", \"\").toLowerCase();\r\n    routes.push({\r\n      path,\r\n      name: path.slice(1),\r\n      component: () => import(`../views${item.slice(1)}`),\r\n    });\r\n  });\r\n\r\nconst router = new VueRouter({\r\n  mode: \"history\",\r\n  base: process.env.BASE_URL,\r\n  routes,\r\n});\r\n```\r\n\r\nexport default router;\r\n\r\n2. 将需要生成路由的.vue文件创建在views目录下即可\r\n', '2022-04-14 21:47:08', 'https://picsum.photos/id/1008/800/450', '原创', b'1', b'1', b'1', '路由自动添加', '2022-03-10 16:26:23', 12, 38, 1, '不论是vue项目还是react项目，在添加新功能页面时，都需要进行手动配置路由表才会生效。\r\n那么有没有可能在按照一定格式创建文件之后，会自动添加到路由配置表 里呢？');
INSERT INTO `t_blog` VALUES (31, b'1', b'0', '### 一、slot是什么\r\n在HTML中 slot 元素 ，作为 Web Components 技术套件的一部分，是Web组件内的一个占位符\r\n\r\n该占位符可以在后期使用自己的标记语言填充\r\n\r\n#### 举个栗子\r\n\r\n```delphi\r\n<template id=\"element-details-template\">\r\n  <slot name=\"element-name\">Slot template</slot>\r\n</template>\r\n<element-details>\r\n  <span slot=\"element-name\">1</span>\r\n</element-details>\r\n<element-details>\r\n  <span slot=\"element-name\">2</span>\r\n</element-details>\r\n```\r\ntemplate不会展示到页面中，需要用先获取它的引用，然后添加到DOM中，\r\n\r\n```delphi\r\ncustomElements.define(\'element-details\',\r\n  class extends HTMLElement {\r\n    constructor() {\r\n      super();\r\n      const template = document\r\n        .getElementById(\'element-details-template\')\r\n        .content;\r\n      const shadowRoot = this.attachShadow({mode: \'open\'})\r\n        .appendChild(template.cloneNode(true));\r\n  }\r\n})\r\n```\r\n在Vue中的概念也是如此\r\n\r\nSlot 艺名插槽，花名“占坑”，我们可以理解为solt在组件模板中占好了位置，当使用该组件标签时候，组件标签里面的内容就会自动填坑（替换组件模板中slot位置），作为承载分发内容的出口\r\n\r\n可以将其类比为插卡式的FC游戏机，游戏机暴露卡槽（插槽）让用户插入不同的游戏磁条（自定义内容）\r\n\r\n## 修改一下\r\n', '2022-04-14 21:47:05', 'https://picsum.photos/id/1011/800/450', '转载', b'1', b'1', b'1', '对slot的理解', '2021-12-23 16:27:35', 3, 6, 1, '在HTML中 slot 元素 ，作为 Web Components 技术套件的一部分，是Web组件内的一个占位符，该占位符可以在后期使用自己的标记语言填充。');
INSERT INTO `t_blog` VALUES (32, b'1', b'1', 'MySQL 数据表是由行和列构成的，通常把表的“列”称为字段（Field），把表的“行”称为记录（Record）。随着业务的变化，可能需要在已有的表中添加新的字段。\r\n\r\nMySQL 允许在开头、中间和结尾处添加字段。\r\n在末尾添加字段\r\n一个完整的字段包括字段名、数据类型和约束条件。MySQL 添加字段的语法格式如下：\r\nALTER TABLE <表名> ADD <新字段名><数据类型>[约束条件];\r\n\r\n对语法格式的说明如下：                                       \r\n<表名> 为数据表的名字；\r\n<新字段名> 为所要添加的字段的名字；\r\n<数据类型> 为所要添加的字段能存储数据的数据类型；\r\n[约束条件] 是可选的，用来对添加的字段进行约束。\r\n\r\n这种语法格式默认在表的最后位置（最后一列的后面）添加新字段。\r\n注意：本节我们只添加新的字段，不关注它的约束条件。\r\n\r\n实例1\r\n在 test 数据库中新建 student 数据表，SQL 语句和运行结果如下：\r\n```sql\r\nmysql> USE test;\r\nDatabase changed\r\nmysql> CREATE TABLE student (\r\n    -> id INT(4),\r\n    -> name VARCHAR(20),\r\n    -> sex CHAR(1));\r\nQuery OK, 0 rows affected (0.09 sec)\r\n```                           \r\n\r\n使用 DESC 查看 student 表结构，SQL 语句和运行结果如下：\r\n```sql\r\nmysql> DESC student;\r\n+-------+-------------+------+-----+---------+-------+\r\n| Field | Type        | Null | Key | Default | Extra |\r\n+-------+-------------+------+-----+---------+-------+\r\n| id    | int(4)      | YES  |     | NULL    |       |\r\n| name  | varchar(20) | YES  |     | NULL    |       |\r\n| sex   | char(1)     | YES  |     | NULL    |       |\r\n+-------+-------------+------+-----+---------+-------+\r\n3 rows in set (0.01 sec)\r\n \r\n```\r\n使用 ALTER TABLE 语句添加一个 INT 类型的字段 age，SQL 语句和运行结果如下：\r\n```sql\r\nmysql> ALTER TABLE student ADD age INT(4);\r\nQuery OK, 0 rows affected (0.16 sec)\r\nRecords: 0  Duplicates: 0  Warnings: 0\r\n```\r\n\r\n使用 DESC 查看 student 表结构，检验 age 字段是否添加成功。SQL 语句和运行结果如下：\r\n```sql\r\nmysql> DESC student;\r\n+-------+-------------+------+-----+---------+-------+\r\n| Field | Type        | Null | Key | Default | Extra |\r\n+-------+-------------+------+-----+---------+-------+\r\n| id    | int(4)      | YES  |     | NULL    |       |\r\n| name  | varchar(20) | YES  |     | NULL    |       |\r\n| sex   | char(1)     | YES  |     | NULL    |       |\r\n| age   | int(4)      | YES  |     | NULL    |       |\r\n+-------+-------------+------+-----+---------+-------+\r\n4 rows in set (0.00 sec)\r\n```\r\n由运行结果可以看到，student 表已经添加了 age 字段，且该字段在表的最后一个位置，添加字段成功。\r\n在开头添加字段\r\nMySQL 默认在表的最后位置添加新字段，如果希望在开头位置（第一列的前面）添加新字段，那么可以使用 FIRST 关键字，语法格式如下：\r\n```sql\r\nALTER TABLE <表名> ADD <新字段名> <数据类型> [约束条件] FIRST;\r\n```\r\n\r\nFIRST 关键字一般放在语句的末尾。\r\n实例2\r\n使用 ALTER TABLE 语句在表的第一列添加 INT 类型的字段 stuId，SQL 语句和运行结果如下所示。\r\n```sql\r\nmysql> ALTER TABLE student ADD stuId INT(4) FIRST;\r\nQuery OK, 0 rows affected (0.14 sec)\r\nRecords: 0  Duplicates: 0  Warnings: 0\r\n\r\nmysql> DESC student;\r\n+-------+-------------+------+-----+---------+-------+\r\n| Field | Type        | Null | Key | Default | Extra |\r\n+-------+-------------+------+-----+---------+-------+\r\n| stuId | int(4)      | YES  |     | NULL    |       |\r\n| id    | int(4)      | YES  |     | NULL    |       |\r\n| name  | varchar(20) | YES  |     | NULL    |       |\r\n| sex   | char(1)     | YES  |     | NULL    |       |\r\n| age   | int(4)      | YES  |     | NULL    |       |\r\n+-------+-------------+------+-----+---------+-------+\r\n5 rows in set (0.00 sec)\r\n```\r\n由运行结果可以看到，student 表中已经添加了 stuId 字段，且该字段在表中的第一个位置，添加字段成功。\r\n在中间位置添加字段\r\nMySQL 除了允许在表的开头位置和末尾位置添加字段外，还允许在中间位置（指定的字段之后）添加字段，此时需要使用 AFTER 关键字，语法格式如下：\r\nALTER TABLE <表名> ADD <新字段名> <数据类型> [约束条件] AFTER <已经存在的字段名>;\r\n\r\nAFTER 的作用是将新字段添加到某个已有字段后面。\r\n\r\n注意，只能在某个已有字段的后面添加新字段，不能在它的前面添加新字段。\r\n实例3\r\n使用 ALTER TABLE 语句在 student 表中添加名为 stuno，数据类型为 INT 的字段，stuno 字段位于 name 字段的后面。SQL 语句和运行结果如下：\r\n```sql\r\nmysql> ALTER TABLE student ADD stuno INT(11) AFTER name;\r\nQuery OK, 0 rows affected (0.13 sec)\r\nRecords: 0  Duplicates: 0  Warnings: 0\r\n \r\nmysql> DESC student;\r\n+-------+-------------+------+-----+---------+-------+\r\n| Field | Type        | Null | Key | Default | Extra |\r\n+-------+-------------+------+-----+---------+-------+\r\n| stuId | int(4)      | YES  |     | NULL    |       |\r\n| id    | int(4)      | YES  |     | NULL    |       |\r\n| name  | varchar(20) | YES  |     | NULL    |       |\r\n| stuno | int(11)     | YES  |     | NULL    |       |\r\n| sex   | char(1)     | YES  |     | NULL    |       |\r\n| age   | int(4)      | YES  |     | NULL    |       |\r\n+-------+-------------+------+-----+---------+-------+\r\n6 rows in set (0.00 sec)\r\n```\r\n由运行结果可以看到，student 表中已经添加了 stuId 字段，且该字段在 name 字段后面的位置，添加字段成功。', '2022-04-15 21:46:59', 'https://picsum.photos/id/1027/800/450', '转载', b'1', b'1', b'1', 'MSQL数据表添加字段的方式', '2021-12-18 16:24:48', 4, 34, 1, 'MySQL 数据表是由行和列构成的，通常把表的“列”称为字段（Field），把表的“行”称为记录（Record）。随着业务的变化，可能需要在已有的表中添加新的字段。');
INSERT INTO `t_blog` VALUES (33, b'1', b'1', '索引是一种特殊的数据库结构，由数据表中的一列或多列组合而成，可以用来快速查询数据表中有某一特定值的记录。本节将详细讲解索引的含义、作用和优缺点。\r\n\r\n通过索引，查询数据时不用读完记录的所有信息，而只是查询索引列。否则，数据库系统将读取每条记录的所有信息进行匹配。\r\n\r\n可以把索引比作新华字典的音序表。例如，要查“库”字，如果不使用音序，就需要从字典的 400 页中逐页来找。但是，如果提取拼音出来，构成音序表，就只需要从 10 多页的音序表中直接查找。这样就可以大大节省时间。\r\n\r\n因此，使用索引可以很大程度上提高数据库的查询速度，还有效的提高了数据库系统的性能。\r\n为什么要使用索引\r\n索引就是根据表中的一列或若干列按照一定顺序建立的列值与记录行之间的对应关系表，实质上是一张描述索引列的列值与原表中记录行之间一 一对应关系的有序表。\r\n\r\n索引是 MySQL 中十分重要的数据库对象，是数据库性能调优技术的基础，常用于实现数据的快速检索。\r\n\r\n在 MySQL 中，通常有以下两种方式访问数据库表的行数据：\r\n##### 1) 顺序访问\r\n顺序访问是在表中实行全表扫描，从头到尾逐行遍历，直到在无序的行数据中找到符合条件的目标数据。\r\n\r\n顺序访问实现比较简单，但是当表中有大量数据的时候，效率非常低下。例如，在几千万条数据中查找少量的数据时，使用顺序访问方式将会遍历所有的数据，花费大量的时间，显然会影响数据库的处理性能。\r\n##### 2) 索引访问\r\n索引访问是通过遍历索引来直接访问表中记录行的方式。\r\n\r\n使用这种方式的前提是对表建立一个索引，在列上创建了索引之后，查找数据时可以直接根据该列上的索引找到对应记录行的位置，从而快捷地查找到数据。索引存储了指定列数据值的指针，根据指定的排序顺序对这些指针排序。\r\n\r\n例如，在学生基本信息表 tb_students 中，如果基于 student_id 建立了索引，系统就建立了一张索引列到实际记录的映射表。当用户需要查找 student_id 为 12022 的数据的时候，系统先在 student_id 索引上找到该记录，然后通过映射表直接找到数据行，并且返回该行数据。因为扫描索引的速度一般远远大于扫描实际数据行的速度，所以采用索引的方式可以大大提高数据库的工作效率。\r\n\r\n简而言之，不使用索引，MySQL 就必须从第一条记录开始读完整个表，直到找出相关的行。表越大，查询数据所花费的时间就越多。如果表中查询的列有一个索引，MySQL 就能快速到达一个位置去搜索数据文件，而不必查看所有数据，这样将会节省很大一部分时间。\r\n## 索引的优缺点\r\n索引有其明显的优势，也有其不可避免的缺点。\r\n#### 优点\r\n索引的优点如下：\r\n通过创建唯一索引可以保证数据库表中每一行数据的唯一性。\r\n可以给所有的 MySQL 列类型设置索引。\r\n可以大大加快数据的查询速度，这是使用索引最主要的原因。\r\n在实现数据的参考完整性方面可以加速表与表之间的连接。\r\n在使用分组和排序子句进行数据查询时也可以显著减少查询中分组和排序的时间\r\n#### 缺点\r\n增加索引也有许多不利的方面，主要如下：\r\n创建和维护索引组要耗费时间，并且随着数据量的增加所耗费的时间也会增加。\r\n索引需要占磁盘空间，除了数据表占数据空间以外，每一个索引还要占一定的物理空间。如果有大量的索引，索引文件可能比数据文件更快达到最大文件尺寸。\r\n当对表中的数据进行增加、删除和修改的时候，索引也要动态维护，这样就降低了数据的维护速度。\r\n\r\n使用索引时，需要综合考虑索引的优点和缺点。\r\n\r\n索引可以提高查询速度，但是会影响插入记录的速度。因为，向有索引的表中插入记录时，数据库系统会按照索引进行排序，这样就降低了插入记录的速度，插入大量记录时的速度影响会更加明显。这种情况下，最好的办法是先删除表中的索引，然后插入数据，插入完成后，再创建索引。', '2022-04-06 21:46:56', 'https://picsum.photos/id/1004/800/450', '转载', b'1', b'1', b'1', 'MySQL索引是什么？', '2021-12-26 16:25:22', 4, 34, 1, '索引是一种特殊的数据库结构，由数据表中的一列或多列组合而成，可以用来快速查询数据表中有某一特定值的记录。本节将详细讲解索引的含义、作用和优缺点。');
INSERT INTO `t_blog` VALUES (37, b'1', b'0', '我们必须有恒心，尤其要有自信力！我们必须相信我们的天赋是要用来做某种事情的，无论代价多么大，这种事情必须做到。\r\n\r\n\r\n\r\n　　——居里夫人\r\n\r\n\r\n\r\n　　相信自己，就是要‘自信’，就是面对困难、挫折和新的挑战不要折服，不要胆怯。面对困难、挫折、挑战只要你肯相信自己，不断努力的付出，哪怕你现在的人生是从零开始，你都可以做得到。\r\n\r\n[![](https://tse4-mm.cn.bing.net/th/id/OIP-C.dtT93FZ1Sz9M1LKVu-nlGQHaEK?pid=ImgDet&rs=1)](https://tse4-mm.cn.bing.net/th/id/OIP-C.dtT93FZ1Sz9M1LKVu-nlGQHaEK?pid=ImgDet&rs=1)\r\n\r\n\r\n\r\n　　苦难是无情的，即便你是王公贵族，一样会遇到无情的苦难和人生的挫折。人生的道路上，无论如何都回避不了现实的重重困难，事业、爱情没有永远的一帆风顺，家庭、学业没有真正的心想事成。但是，只要你不去推诿，不胆怯，保持信心满满，保持良好的心态和旺盛的精力，努力的奋进，你就一定会知道“发光并非太阳的专利，你也可以发光。”\r\n\r\n\r\n\r\n　　相信自己，你就一定可以做得到！', '2022-04-25 17:49:25', 'https://pic1.zhimg.com/v2-fdddb88610ae48582844f6abcc81612c_1440w.jpg?source=172ae18b', '转载', b'1', b'1', b'1', '相信自己', '2022-08-24 20:05:36', 3, 35, 1, '我们必须有恒心，尤其要有自信力！我们必须相信我们的天赋是要用来做某种事情的，无论代价多么大，这种事情必须做到。\r\n\r\n\r\n\r\n——居里夫人');
INSERT INTO `t_blog` VALUES (39, b'0', b'0', '# 简介\r\nTCP是一种面向连接的、可靠的、基于字节流的传输层通信协议，在发送数据前，通信双方必须在彼此间建立一条连接。所谓的“连接”，其实是客户端和服务端保存的一份关于对方的信息，如ip地址、端口号等。TCP可以看成是一种字节流，它会处理IP层或以下的层的丢包、重复以及错误问题。在连接的建立过程中，双方需要交换一些连接的参数。这些参数可以放在TCP头部。一个TCP连接由一个4元组构成，分别是两个IP地址和两个端口号。一个TCP连接通常分为三个阶段：连接、数据传输、退出（关闭）。通过三次握手建立一个链接，通过四次挥手来关闭一个连接。当一个连接被建立或被终止时，交换的报文段只包含TCP头部，而没有数据。\r\n\r\n## 1. TCP报文的头部结构\r\n在了解TCP连接之前先来了解一下TCP报文的头部结构。\r\n上图中有几个字段需要重点介绍下：\r\n（1）序号：seq序号，占32位，用来标识从TCP源端向目的端发送的字节流，发起方发送数据时对此进行标记。\r\n（2）确认序号：ack序号，占32位，只有ACK标志位为1时，确认序号字段才有效，ack=seq+1。\r\n（3）标志位：共6个，即URG、ACK、PSH、RST、SYN、FIN等，具体含义如下：\r\n\r\n```asp\r\nACK：确认序号有效。\r\nFIN：释放一个连接。\r\nPSH：接收方应该尽快将这个报文交给应用层。\r\nRST：重置连接。SYN：发起一个新连接。\r\nURG：紧急指针（urgent pointer）有效。需要注意的是：不要将确认序号ack与标志位中的ACK搞混了。确认方ack=发起方seq+1，两端配对。\r\n```\r\n## 2. 三次握手\r\n三次握手的本质是确认通信双方收发数据的能力首先，我让信使运输一份信件给对方，对方收到了，那么他就知道了我的发件能力和他的收件能力是可以的。于是他给我回信，我若收到了，我便知我的发件能力和他的收件能力是可以的，并且他的发件能力和我的收件能力是可以。然而此时他还不知道他的发件能力和我的收件能力到底可不可以，于是我最后回馈一次，他若收到了，他便清楚了他的发件能力和我的收件能力是可以的。这，就是三次握手。\r\n图片\r\n**第一次握手**：客户端要向服务端发起连接请求，首先客户端随机生成一个起始序列号ISN(比如是100)，那客户端向服务端发送的报文段包含SYN标志位(也就是SYN=1)，序列号seq=100。\r\n**第二次握手**：服务端收到客户端发过来的报文后，发现SYN=1，知道这是一个连接请求，于是将客户端的起始序列号100存起来，并且随机生成一个服务端的起始序列号(比如是300)。然后给客户端回复一段报文，回复报文包含SYN和ACK标志(也就是SYN=1,ACK=1)、序列号seq=300、确认号ack=101(客户端发过来的序列号+1)。\r\n**第三次握手**：客户端收到服务端的回复后发现ACK=1并且ack=101,于是知道服务端已经收到了序列号为100的那段报文；同时发现SYN=1，知道了服务端同意了这次连接，于是就将服务端的序列号300给存下来。然后客户端再回复一段报文给服务端，报文包含ACK标志位(ACK=1)、ack=301(服务端序列号+1)、seq=101(第一次握手时发送报文是占据一个序列号的，所以这次seq就从101开始，需要注意的是不携带数据的ACK报文是不占据序列号的，所以后面第一次正式发送数据时seq还是101)。当服务端收到报文后发现ACK=1并且ack=301，就知道客户端收到序列号为300的报文了，就这样客户端和服务端通过TCP建立了连接。\r\n## 3. 四次挥手\r\n四次挥手的目的是关闭一个连接\r\n图片\r\n比如客户端初始化的序列号ISA=100，服务端初始化的序列号ISA=300。TCP连接成功后客户端总共发送了1000个字节的数据，服务端在客户端发FIN报文前总共回复了2000个字节的数据。\r\n\r\n**第一次挥手**：当客户端的数据都传输完成后，客户端向服务端发出连接释放报文(当然数据没发完时也可以发送连接释放报文并停止发送数据)，释放连接报文包含FIN标志位(FIN=1)、序列号seq=1101(100+1+1000，其中的1是建立连接时占的一个序列号)。需要注意的是客户端发出FIN报文段后只是不能发数据了，但是还可以正常收数据；另外FIN报文段即使不携带数据也要占据一个序列号。\r\n**第二次挥手**：服务端收到客户端发的FIN报文后给客户端回复确认报文，确认报文包含ACK标志位(ACK=1)、确认号ack=1102(客户端FIN报文序列号1101+1)、序列号seq=2300(300+2000)。此时服务端处于关闭等待状态，而不是立马给客户端发FIN报文，这个状态还要持续一段时间，因为服务端可能还有数据没发完。\r\n**第三次挥手**：服务端将最后数据(比如50个字节)发送完毕后就向客户端发出连接释放报文，报文包含FIN和ACK标志位(FIN=1,ACK=1)、确认号和第二次挥手一样ack=1102、序列号seq=2350(2300+50)。\r\n**第四次挥手**：客户端收到服务端发的FIN报文后，向服务端发出确认报文，确认报文包含ACK标志位(ACK=1)、确认号ack=2351、序列号seq=1102。注意客户端发出确认报文后不是立马释放TCP连接，而是要经过2MSL(最长报文段寿命的2倍时长)后才释放TCP连接。而服务端一旦收到客户端发出的确认报文就会立马释放TCP连接，所以服务端结束TCP连接的时间要比客户端早一些。\r\n## 4. 常见面试题\r\n### 为什么TCP连接的时候是3次？2次不可以吗？\r\n因为需要考虑连接时丢包的问题，如果只握手2次，第二次握手时如果服务端发给客户端的确认报文段丢失，此时服务端已经准备好了收发数(可以理解服务端已经连接成功)据，而客户端一直没收到服务端的确认报文，所以客户端就不知道服务端是否已经准备好了(可以理解为客户端未连接成功)，这种情况下客户端不会给服务端发数据，也会忽略服务端发过来的数据。如果是三次握手，即便发生丢包也不会有问题，比如如果第三次握手客户端发的确认ack报文丢失，服务端在一段时间内没有收到确认ack报文的话就会重新进行第二次握手，也就是服务端会重发SYN报文段，客户端收到重发的报文段后会再次给服务端发送确认ack报文。\r\n### 为什么TCP连接的时候是3次，关闭的时候却是4次？\r\n因为只有在客户端和服务端都没有数据要发送的时候才能断开TCP。而客户端发出FIN报文时只能保证客户端没有数据发了，服务端还有没有数据发客户端是不知道的。而服务端收到客户端的FIN报文后只能先回复客户端一个确认报文来告诉客户端我服务端已经收到你的FIN报文了，但我服务端还有一些数据没发完，等这些数据发完了服务端才能给客户端发FIN报文(所以不能一次性将确认报文和FIN报文发给客户端，就是这里多出来了一次)。\r\n### 为什么客户端发出第四次挥手的确认报文后要等2MSL的时间才能释放TCP连接？\r\n这里同样是要考虑丢包的问题，如果第四次挥手的报文丢失，服务端没收到确认ack报文就会重发第三次挥手的报文，这样报文一去一回最长时间就是2MSL，所以需要等这么长时间来确认服务端确实已经收到了。', '2022-04-27 11:48:35', 'https://picsum.photos/id/1000/800/450', '转载', b'1', b'0', b'0', 'TCP的三次握手', '2022-05-14 15:45:45', 11, 38, 1, 'TCP是一种面向连接的、可靠的、基于字节流的传输层通信协议，在发送数据前，通信双方必须在彼此间建立一条连接。所谓的“连接”，其实是客户端和服务端保存的一份关于对方的信息，如ip地址、端口号等。');
INSERT INTO `t_blog` VALUES (59, b'1', b'1', 'thymeleaf + Spring Boot 在开发环境正常，但用jar运行时报错 Error resolving template template might not exist or might not be accessible;\r\n\r\n \r\n\r\n这个问题我们都很好明白，就是模板页不存在，但是实际上它能找到模板页，但是在使用th:include标签的时候才会出错，这就是问题的症结所在。\r\n\r\n其实这个问题也很好解决，我们只需要在引用模板文件的时候不用”/”打头就可以了，通过类似相对路径的方式来引用，但是需要说明的是，这里的相对路径仍然是相对于模板根目录来做的。\r\n\r\n```java\r\n@RequestMapping(\"/view\")\r\npublic String view()  {\r\n    return \"/view\";\r\n}\r\n```\r\n改成\r\n\r\n```java\r\n@RequestMapping(\"/view\")\r\npublic String view()  {\r\n    return \"view\";\r\n}\r\n```\r\n就可以了\r\n\r\n另一种解决方案：\r\n\r\n```xml\r\nspring.thymeleaf.cache=false\r\nspring.thymeleaf.prefix=classpath:/templates/\r\nspring.thymeleaf.suffix=.html\r\n```\r\n\r\n改成\r\n```xml\r\nspring.thymeleaf.cache=false\r\nspring.thymeleaf.prefix=classpath:/templates\r\nspring.thymeleaf.suffix=.html\r\n```\r\n————————————————\r\n版权声明：本文为CSDN博主「寻梦的飞鱼」的原创文章，遵循CC 4.0 BY-SA版权协议，转载请附上原文出处链接及本声明。\r\n原文链接：https://blog.csdn.net/qq_31638493/article/details/81207595', '2022-08-24 20:28:50', 'https://picsum.photos/id/1010/800/450', '转载', b'1', b'1', b'1', 'IDEA报错之500（1）', '2022-08-24 22:18:16', 2, 2, 1, '解决Error resolving template template might not exist or might not be accessible问题');

-- ----------------------------
-- Table structure for t_blog_tags
-- ----------------------------
DROP TABLE IF EXISTS `t_blog_tags`;
CREATE TABLE `t_blog_tags`  (
  `blogs_id` bigint(20) NOT NULL,
  `tags_id` bigint(20) NOT NULL,
  INDEX `FK5feau0gb4lq47fdb03uboswm8`(`tags_id`) USING BTREE,
  INDEX `FKh4pacwjwofrugxa9hpwaxg6mr`(`blogs_id`) USING BTREE,
  CONSTRAINT `FK5feau0gb4lq47fdb03uboswm8` FOREIGN KEY (`tags_id`) REFERENCES `t_tag` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKh4pacwjwofrugxa9hpwaxg6mr` FOREIGN KEY (`blogs_id`) REFERENCES `t_blog` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of t_blog_tags
-- ----------------------------
INSERT INTO `t_blog_tags` VALUES (32, 16);
INSERT INTO `t_blog_tags` VALUES (32, 17);
INSERT INTO `t_blog_tags` VALUES (32, 40);
INSERT INTO `t_blog_tags` VALUES (33, 1);
INSERT INTO `t_blog_tags` VALUES (33, 16);
INSERT INTO `t_blog_tags` VALUES (33, 40);
INSERT INTO `t_blog_tags` VALUES (29, 15);
INSERT INTO `t_blog_tags` VALUES (29, 40);
INSERT INTO `t_blog_tags` VALUES (31, 12);
INSERT INTO `t_blog_tags` VALUES (31, 13);
INSERT INTO `t_blog_tags` VALUES (28, 1);
INSERT INTO `t_blog_tags` VALUES (28, 17);
INSERT INTO `t_blog_tags` VALUES (28, 18);
INSERT INTO `t_blog_tags` VALUES (28, 19);
INSERT INTO `t_blog_tags` VALUES (39, 1);
INSERT INTO `t_blog_tags` VALUES (39, 15);
INSERT INTO `t_blog_tags` VALUES (39, 40);
INSERT INTO `t_blog_tags` VALUES (37, 17);
INSERT INTO `t_blog_tags` VALUES (37, 18);
INSERT INTO `t_blog_tags` VALUES (37, 19);
INSERT INTO `t_blog_tags` VALUES (59, 13);
INSERT INTO `t_blog_tags` VALUES (59, 40);

-- ----------------------------
-- Table structure for t_comment
-- ----------------------------
DROP TABLE IF EXISTS `t_comment`;
CREATE TABLE `t_comment`  (
  `id` bigint(20) NOT NULL,
  `avatar` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `content` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `create_time` datetime NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `nickname` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `blog_id` bigint(20) NULL DEFAULT NULL,
  `parent_comment_id` bigint(20) NULL DEFAULT NULL,
  `admin_comment` bit(1) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FKke3uogd04j4jx316m1p51e05u`(`blog_id`) USING BTREE,
  INDEX `FK4jj284r3pb7japogvo6h72q95`(`parent_comment_id`) USING BTREE,
  CONSTRAINT `FK4jj284r3pb7japogvo6h72q95` FOREIGN KEY (`parent_comment_id`) REFERENCES `t_comment` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKke3uogd04j4jx316m1p51e05u` FOREIGN KEY (`blog_id`) REFERENCES `t_blog` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of t_comment
-- ----------------------------
INSERT INTO `t_comment` VALUES (56, 'https://picsum.photos/id/1008/100/100', '测试评论功能', '2022-05-14 11:55:20', '1547312521@qq.com', '陈富强', 31, NULL, b'1');
INSERT INTO `t_comment` VALUES (57, 'https://picsum.photos/100/100', '博主真的六六六', '2022-05-15 10:55:56', '1547312521@qq.com', '刘粉胶', 28, NULL, b'0');
INSERT INTO `t_comment` VALUES (58, 'https://picsum.photos/id/1008/100/100', '确实确实', '2022-05-15 11:19:26', '1547312521@qq.com', 'Axiosk', 28, 57, b'1');
INSERT INTO `t_comment` VALUES (60, 'https://picsum.photos/id/1008/100/100', '欢迎评论', '2022-08-31 20:07:26', '1547312521@qq.com', 'Axiosk', 59, NULL, b'1');

-- ----------------------------
-- Table structure for t_tag
-- ----------------------------
DROP TABLE IF EXISTS `t_tag`;
CREATE TABLE `t_tag`  (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of t_tag
-- ----------------------------
INSERT INTO `t_tag` VALUES (1, '方法论');
INSERT INTO `t_tag` VALUES (12, 'HTML与CSS');
INSERT INTO `t_tag` VALUES (13, 'Java基础与框架学习');
INSERT INTO `t_tag` VALUES (14, 'Python');
INSERT INTO `t_tag` VALUES (15, '网络');
INSERT INTO `t_tag` VALUES (16, '数据库');
INSERT INTO `t_tag` VALUES (17, '博客');
INSERT INTO `t_tag` VALUES (18, '个人');
INSERT INTO `t_tag` VALUES (19, '情感');
INSERT INTO `t_tag` VALUES (40, '学习');

-- ----------------------------
-- Table structure for t_type
-- ----------------------------
DROP TABLE IF EXISTS `t_type`;
CREATE TABLE `t_type`  (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of t_type
-- ----------------------------
INSERT INTO `t_type` VALUES (1, '关于刻意练习');
INSERT INTO `t_type` VALUES (2, '错误日志');
INSERT INTO `t_type` VALUES (3, 'JavaScript学习');
INSERT INTO `t_type` VALUES (4, '认知升级');
INSERT INTO `t_type` VALUES (5, 'Java基础与框架学习');
INSERT INTO `t_type` VALUES (6, 'HTML与CSS学习');
INSERT INTO `t_type` VALUES (11, 'python学习');
INSERT INTO `t_type` VALUES (34, '数据库学习');
INSERT INTO `t_type` VALUES (35, '心灵鸡汤');
INSERT INTO `t_type` VALUES (36, '学习方法');
INSERT INTO `t_type` VALUES (38, '网络学习');

-- ----------------------------
-- Table structure for t_user
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user`  (
  `user` bigint(20) NOT NULL,
  `avatar` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `create_time` datetime NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `nickname` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `type` int(11) NULL DEFAULT NULL,
  `update_time` datetime NULL DEFAULT NULL,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`user`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES (1, 'https://picsum.photos/id/1008/100/100', '2022-04-14 17:12:31', '1547312521@qq.com', 'Axiosk', 'e10adc3949ba59abbe56e057f20f883e', 1, '2022-04-15 17:13:22', 'chenfq');

-- ----------------------------
-- Procedure structure for test
-- ----------------------------
DROP PROCEDURE IF EXISTS `test`;
delimiter ;;
CREATE PROCEDURE `test`()
BEGIN
    declare n bigint;  
    set n = 2;  
    while n <= 210 do  
    set n = n + 1;
        INSERT INTO `travel`.`tab_category_route` (`rid`, `cid`)
 VALUES (n, '5');  
end while;  
END
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
