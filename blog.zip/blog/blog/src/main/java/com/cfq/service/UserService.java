package com.cfq.service;

import com.cfq.po.User;

public interface UserService {

    User checkUser(String username, String password);
}
