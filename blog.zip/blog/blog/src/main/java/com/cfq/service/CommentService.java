package com.cfq.service;

import com.cfq.po.Comment;

import java.util.List;

public interface CommentService {

    List<Comment> listCommentByBlogId(Long blogId);

    Comment savaComment(Comment comment);
}
