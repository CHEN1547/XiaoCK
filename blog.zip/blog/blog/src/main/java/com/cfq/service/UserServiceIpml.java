package com.cfq.service;
import com.cfq.dao.UserRepository;
import com.cfq.po.User;
import com.cfq.util.MD5Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceIpml implements UserService{

    @Autowired
    private UserRepository userRepository;


    @Override
    public User checkUser(String username, String password) {
        User user = userRepository.findByUsernameAndAndPassword(username, MD5Utils.code(password));
        return user;
    }
}
